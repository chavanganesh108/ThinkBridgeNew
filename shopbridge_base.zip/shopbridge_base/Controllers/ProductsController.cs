﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Shopbridge_base.Data;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;

namespace Shopbridge_base.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        #region declaration
        private readonly IProductService productService;
        private readonly ILogger<ProductsController> logger;
        #endregion

        #region ctor

        public ProductsController(IProductService _productService)
        {
            this.productService = _productService;
        }
        #endregion

        #region Methods

        
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProduct()
        {
            string[] IncludeObject = { "productImages", "productsizes", "productcolors" };
            var data = await productService.GetProducts(IncludeObject);
           
            if (data != null)
                return Ok(data);

            return NotFound();
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            string[] IncludeObject = { "productImages", "productsizes", "productcolors" };
            var data = await productService.GetProductsById(id, IncludeObject);

            if (data != null)
                return Ok(data);

            return NotFound();

        }


        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id,[FromBody] Product productModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(productModel);
            }
            else
            {
                string[] IncludeObject = { "productImages", "productsizes", "productcolors" };
                var record = await productService.GetProductsById(id, IncludeObject);
                if (record != null)
                {
                    record.Name = productModel.Name;
                    record.Description = productModel.Description;
                    record.Price = productModel.Price;
                    record.Category = productModel.Category;
                    record.Stock = productModel.Stock;
                    record.Weight = productModel.Weight;
                    record.ProductLocation = productModel.ProductLocation;
                    record.Discount = productModel.Discount;
                    record.DiscountValue = productModel.Discount != 0 ? productModel.Price - (productModel.Price * productModel.Discount / 100) : 0;
                    record.SKU = productModel.SKU;
                    record.SupplierName = productModel.SupplierName;
                    record.ProductAvailable = productModel.ProductAvailable;
                    record.HSNCode = productModel.HSNCode;
                    record.productImages = productModel.productImages;
                    record.productsizes = productModel.productsizes;
                    record.productcolors = productModel.productcolors;
                    await productService.UpdateProducts(record);
                    return Created("~api/Products", productModel); ;
                }
                return NotFound();
            }
        }


        [HttpPost]
        public async Task<ActionResult<Product>> PostProduct([FromBody] Product productModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(productModel);
            }
            else
            {
                if (productModel != null)
                {
                    productModel.DiscountValue = productModel.Discount != 0 ? productModel.Price - (productModel.Price * productModel.Discount / 100) : 0;
                    await productService.AddProduct(productModel);
                    return Ok(productModel);
                }
                return NotFound();
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var record = await productService.GetProductsById(id);
            if (record != null)
            {
                await productService.RemoveProducts(record);
                return Ok();
            }
            return NotFound();

        }
        #endregion
    }
}
