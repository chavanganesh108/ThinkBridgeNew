﻿using Microsoft.Extensions.Logging;
using Shopbridge_base.Domain.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Shopbridge_base.Data.Repository;
using Shopbridge_base.Domain.Models;

namespace Shopbridge_base.Domain.Services
{
    public class ProductService : IProductService
    {
        #region declaration

        
        private readonly ILogger<ProductService> logger;
        private readonly IRepository<Product> repository;
        #endregion
        #region ctor
        public ProductService(IRepository<Product> _repository)
        {
            repository = _repository;
        }
        #endregion

        #region method

        
        public Task AddProduct(Product _product)
        {
          return  repository.Add(_product);
        }

        public Task<IEnumerable<Product>> GetProducts(string[] IncludeObject = null)
        {
            return repository.GetAll(IncludeObject);
        }

        public Task<Product> GetProductsById(int id, string[] IncludeObject = null)
        {
            return repository.GetWhere(x => x.Product_Id == id, IncludeObject);
        }

        public Task RemoveProducts(Product _product)
        {
            return repository.Remove(_product);
        }

        public Task UpdateProducts(Product _product)
        {
            return repository.Update(_product);
        }
        #endregion
    }
}
