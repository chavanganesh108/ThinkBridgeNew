﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Domain.Models
{
    public class Product
    {
        public Product()
        {
            productImages = new HashSet<ProductImages>();
            productcolors = new HashSet<ProductColor>();
            productsizes = new HashSet<ProductSize>();
        }
        [Key]
        public int Product_Id { get; set; }
        
        public string Name { get; set; }
        
        public string Description { get; set; }
        
        public decimal Price { get; set; }


        
        public string Category { get; set; }
        
        public int Stock { get; set; }
        
        public string Weight { get; set; }
        
        public string ProductLocation { get; set; }
        
        public decimal Discount { get; set; }

        public decimal DiscountValue { get; set; }
        
        public string SKU { get; set; }
        
        public string SupplierName { get; set; }
        
        public bool ProductAvailable { get; set; }
        
        public string HSNCode { get; set; }

        public virtual ICollection<ProductImages> productImages { get; set; }

        public virtual ICollection<ProductSize> productsizes { get; set; }
        public virtual ICollection<ProductColor> productcolors { get; set; }
    }
}
