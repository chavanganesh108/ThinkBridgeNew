﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Shopbridge_base.Domain.Models;

namespace Shopbridge_base.Data
{
    public class Shopbridge_Context : DbContext
    {
        public Shopbridge_Context(DbContextOptions<Shopbridge_Context> options)
            : base(options)
        {
        }

       
        public DbSet<Product> Product { get; set; }
        public DbSet<ProductImages> ProductImages { get; set; }

        public DbSet<ProductSize> ProductSize { get; set; }
        public DbSet<ProductColor> ProductColor { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .HasMany<ProductImages>(x => x.productImages)
                .WithOne(s => s.Product)
                .HasForeignKey(z => z.Product_Id)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Product>()
                .HasMany<ProductSize>(x => x.productsizes)
                .WithOne(s => s.Product)
                .HasForeignKey(z => z.Product_Id)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Product>()
                .HasMany<ProductColor>(x => x.productcolors)
                .WithOne(s => s.Product)
                .HasForeignKey(z => z.Product_Id)
                .OnDelete(DeleteBehavior.Cascade);


            modelBuilder.Entity<ProductImages>()
                .HasKey(a => new { a.Id, a.Product_Id });
            modelBuilder.Entity<ProductSize>()
                .HasKey(a => new { a.Id, a.Product_Id });
            modelBuilder.Entity<ProductColor>()
                .HasKey(a => new { a.Id, a.Product_Id });
        }

       
    }
}
