﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Shopbridge_base.Data.Repository
{
    public interface IRepository<T> where T :class
    {
        Task Add(T entity);
        Task Update(T entity);
        Task Remove(T entity);

        Task<IEnumerable<T>> GetAll(string[] IncludeObject = null);
        Task<T> GetWhere(Expression<Func<T, bool>> predicate, string[] IncludeObject = null);
        Task<IEnumerable<T>> GetWhereList(Expression<Func<T, bool>> predicate);
    }
}
