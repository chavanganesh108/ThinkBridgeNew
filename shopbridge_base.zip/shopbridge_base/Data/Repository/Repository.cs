﻿using Microsoft.EntityFrameworkCore;
using Shopbridge_base.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Shopbridge_base.Data.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly Shopbridge_Context dbcontext;

        public Repository(Shopbridge_Context _dbcontext)
        {
            this.dbcontext = _dbcontext;
        }

        public async Task Add(T entity)
        {

            await dbcontext.Set<T>().AddAsync(entity);
            await dbcontext.SaveChangesAsync();
        }

        public async Task<IEnumerable<T>> GetAll(string[] IncludeObject = null)
        {
            if (IncludeObject != null)
            {
                if (IncludeObject.Length == 3)
                {
                    return await dbcontext.Set<T>().Include<T>(IncludeObject[0]).Include<T>(IncludeObject[1])
                         .Include<T>(IncludeObject[2]).ToListAsync();
                }
            }

            return await dbcontext.Set<T>().ToListAsync();
        }

        public async Task<T> GetWhere(Expression<Func<T, bool>> predicate, string[] IncludeObject = null)
        {
            if (IncludeObject != null)
            {
                if (IncludeObject.Length == 3)
                {
                    return await dbcontext.Set<T>().Include<T>(IncludeObject[0]).Include<T>(IncludeObject[1])
                         .Include<T>(IncludeObject[2]).Where(predicate).FirstOrDefaultAsync();
                }
            }
            return await dbcontext.Set<T>().Where(predicate).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<T>> GetWhereList(Expression<Func<T, bool>> predicate)
        {
            return await dbcontext.Set<T>().Where(predicate).ToListAsync();
        }
        public Task Remove(T entity)
        {
            dbcontext.Set<T>().Remove(entity);
            return dbcontext.SaveChangesAsync();
        }

        public Task Update(T entity)
        {
            dbcontext.Set<T>();
            dbcontext.Entry(entity).State = EntityState.Modified;
            return dbcontext.SaveChangesAsync();
        }


    }
}
